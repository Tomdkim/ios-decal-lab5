//
//  ChooseThreadTableViewCell.swift
//  snapChatProject
//
//  Created by Paige Plander on 3/8/17.
//  Copyright © 2017 org.iosdecal. All rights reserved.
//

import UIKit

class ChooseThreadTableViewCell: UITableViewCell {
    
    @IBOutlet weak var threadNameLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }

}
